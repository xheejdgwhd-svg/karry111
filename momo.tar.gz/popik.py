import socket, time, threading

# Подключаемся вторым соединением
sock = socket.socket()
sock.connect(("irc.chat.twitch.tv", 6667))
sock.send(b"PASS oauth:6v36ti7vd6n3fyax9znmf82wje4kib\r\n")
sock.send(b"NICK mopsyarka91\r\n")
sock.send(b"JOIN #t2x2\r\n")

time.sleep(2)

t_send = time.time()
sock.send(b"PRIVMSG #henesseyyt :LATENCY_TEST\r\n")

# Слушаем пока не получим своё сообщение обратно
buf = ""
while True:
    data = sock.recv(4096).decode("utf-8", errors="ignore")
    buf += data
    if "LATENCY_TEST" in buf and "PRIVMSG" in buf:
        t_recv = time.time()
        print(f"IRC latency: {round((t_recv - t_send)*1000, 1)}мс")
        break
