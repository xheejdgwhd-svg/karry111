# ============================================================
#  HTTP АКТИВАТОР v2.2
#  Сессия строится ОДИН РАЗ при старте браузера.
#  Keep-alive держит TCP соединение открытым — экономим handshake.
#  В hot-path только один POST, XSRF из кеша.
#  Скорость: ~0.2-0.6 сек
# ============================================================
import requests
from requests.adapters import HTTPAdapter
import threading
import time
from urllib.parse import unquote

from config import TARGET_URL
from logger import log

ACTIVATE_PAGE = "https://donatov.net/profile/dcard/activate"
ACTIVATE_URL  = "https://donatov.net/profile/dcard/activate/request"

_sessions      = {}   # {acc_id: requests.Session}
_sessions_lock = threading.Lock()

# Кеш XSRF токенов — обновляется в фоне, не блокирует hot-path
# {acc_id: {"xsrf": str, "ts": float}}
_xsrf_cache      = {}
_xsrf_cache_lock = threading.Lock()
XSRF_TTL              = 25  # секунд — кеш считается свежим
XSRF_REFRESH_INTERVAL = 15  # фоновый поток обновляет каждые 15с (запас 10с до TTL)

# Таймауты: (connect, read)
# connect=0.5с — с keep-alive почти не тратится
# read=2.0с    — сервер иногда отвечает ~1.5с, не падаем зря в Selenium
TIMEOUT_CONNECT = 0.5
TIMEOUT_READ    = 2.0


# ============================================================
#  ИНИЦИАЛИЗАЦИЯ СЕССИИ — вызывать ОДИН РАЗ после старта браузера
# ============================================================
def init_session(driver, acc_id: int) -> bool:
    """
    Строит requests.Session из куков Chrome.
    Настраивает keep-alive чтобы TCP соединение не закрывалось.
    Вызывается один раз: после setup_browser() в browser.py.
    """
    try:
        cookies = driver.get_cookies()
        if not cookies:
            log(acc_id, "⚠️ HTTP init: куки пустые")
            return False

        session = requests.Session()

        # Keep-alive: держим соединение открытым между запросами
        # pool_maxsize=2 — один для pre-fetch, один для activate
        adapter = HTTPAdapter(
            pool_connections=1,
            pool_maxsize=2,
            max_retries=0,
        )
        session.mount("https://", adapter)
        session.mount("http://",  adapter)

        session.headers.update({
            "User-Agent":         "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                                  "(KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
            "Accept":             "application/json, text/plain, */*",
            "Referer":            ACTIVATE_PAGE,
            "Origin":             "https://donatov.net",
            "Connection":         "keep-alive",
            "sec-ch-ua":          '"Not:A-Brand";v="99", "Google Chrome";v="145"',
            "sec-ch-ua-mobile":   "?0",
            "sec-ch-ua-platform": '"Linux"',
        })

        for c in cookies:
            session.cookies.set(
                c["name"], c["value"],
                domain=c.get("domain", ".donatov.net"),
                path=c.get("path", "/"),
            )

        # Проверяем что есть remember_web — без него сессия бесполезна
        remember = any("remember_web" in c.get("name", "") for c in cookies)
        if not remember:
            log(acc_id, "⚠️ HTTP init: нет remember_web куки")
            return False

        with _sessions_lock:
            _sessions[acc_id] = session

        log(acc_id, "✅ HTTP сессия инициализирована (keep-alive)")
        return True

    except Exception as e:
        log(acc_id, f"⚠️ HTTP init_session: {e}")
        return False


def drop_session(acc_id: int):
    """Удаляет сессию и кеш XSRF — вызывать при остановке браузера."""
    with _sessions_lock:
        _sessions.pop(acc_id, None)
    with _xsrf_cache_lock:
        _xsrf_cache.pop(acc_id, None)


def has_session(acc_id: int) -> bool:
    with _sessions_lock:
        return acc_id in _sessions


def start_xsrf_prefetch(acc_id: int):
    """
    Запускает фоновый поток который обновляет XSRF токен каждые 15с.
    Также держит keep-alive соединение живым.
    """
    def _loop():
        while True:
            with _sessions_lock:
                session = _sessions.get(acc_id)
            if not session:
                break
            t0 = time.time()
            try:
                r = session.get(
                    ACTIVATE_PAGE,
                    timeout=(TIMEOUT_CONNECT, 3.0),
                    allow_redirects=False,  # не тратим время на редиректы
                )
                xsrf = _get_xsrf(session)
                elapsed = round(time.time() - t0, 3)
                if xsrf:
                    with _xsrf_cache_lock:
                        _xsrf_cache[acc_id] = {"xsrf": xsrf, "ts": time.time()}
                    log(acc_id, f"🔄 XSRF pre-fetch ok ({elapsed}с) | {xsrf[:20]}...")
                else:
                    log(acc_id, f"⚠️ XSRF pre-fetch: токен не получен ({elapsed}с, HTTP {r.status_code})")
            except Exception as e:
                log(acc_id, f"⚠️ XSRF pre-fetch: {e}")
            time.sleep(XSRF_REFRESH_INTERVAL)

    t = threading.Thread(target=_loop, daemon=True, name=f"xsrf-prefetch-{acc_id}")
    t.start()
    log(acc_id, f"🔁 XSRF pre-fetch запущен (интервал {XSRF_REFRESH_INTERVAL}с, TTL {XSRF_TTL}с)")


# ============================================================
#  ВНУТРЕННИЕ ХЕЛПЕРЫ
# ============================================================
def _get_xsrf(session: requests.Session) -> str:
    """URL-декодирует XSRF токен из куков сессии."""
    token = (session.cookies.get("XSRF-TOKEN", domain=".donatov.net")
             or session.cookies.get("XSRF-TOKEN", domain="donatov.net")
             or session.cookies.get("XSRF-TOKEN")
             or "")
    return unquote(token)


def _fetch_fresh_tokens(session: requests.Session, acc_id: int) -> str:
    """
    Синхронный GET за свежим XSRF — только когда кеш протух.
    allow_redirects=False — не тратим время на редиректы.
    """
    t0 = time.time()
    try:
        r = session.get(
            ACTIVATE_PAGE,
            timeout=(TIMEOUT_CONNECT, 1.5),
            allow_redirects=False,
        )
        xsrf = _get_xsrf(session)
        elapsed = round(time.time() - t0, 3)
        if xsrf:
            log(acc_id, f"🔄 XSRF синхронно обновлён ({elapsed}с) | {xsrf[:20]}...")
        else:
            set_cookie = r.headers.get("Set-Cookie", "")
            log(acc_id, f"⚠️ GET не вернул XSRF ({elapsed}с, HTTP {r.status_code}) | Set-Cookie: {set_cookie[:100]}")
        return xsrf
    except Exception as e:
        elapsed = round(time.time() - t0, 3)
        log(acc_id, f"⚠️ _fetch_fresh_tokens: {e} ({elapsed}с)")
        return ""


# ============================================================
#  АКТИВАЦИЯ — HOT PATH
# ============================================================
def activate_http(driver, acc_id: int, code: str) -> dict:
    """
    Активирует промокод через HTTP (один POST activate).
    Возвращает {"success": bool, "message": str, "status_code": int,
                "elapsed": float, "dump_records": list}
    """
    t0 = time.time()

    # ── Сессия ──────────────────────────────────────────────
    with _sessions_lock:
        session = _sessions.get(acc_id)

    if not session:
        log(acc_id, "⚠️ HTTP: сессия не найдена — инициализирую...")
        if not init_session(driver, acc_id):
            return {"success": False, "message": "Нет сессии",
                    "status_code": 0, "elapsed": round(time.time()-t0, 3), "dump_records": []}
        with _sessions_lock:
            session = _sessions.get(acc_id)

    # ── XSRF из кеша ────────────────────────────────────────
    with _xsrf_cache_lock:
        cached = _xsrf_cache.get(acc_id, {})
    xsrf      = cached.get("xsrf", "")
    cache_age = round(time.time() - cached.get("ts", 0), 1)

    if not xsrf or cache_age > XSRF_TTL:
        reason = "пустой" if not xsrf else f"устарел {cache_age}с"
        log(acc_id, f"⚠️ XSRF кеш {reason} — GET синхронно")
        xsrf = _fetch_fresh_tokens(session, acc_id)
        if not xsrf:
            return {"success": False, "message": "Нет XSRF токена",
                    "status_code": 0, "elapsed": round(time.time()-t0, 3), "dump_records": []}
        with _xsrf_cache_lock:
            _xsrf_cache[acc_id] = {"xsrf": xsrf, "ts": time.time()}
    else:
        log(acc_id, f"⚡ XSRF кеш: {cache_age}с | {xsrf[:15]}...")

    t_before_post = time.time()
    headers = {
        "Content-Type": "application/json",
        "X-XSRF-TOKEN": xsrf,
    }

    # Детальный дамп — точное время каждого этапа
    t_xsrf_ready = round(t_before_post - t0, 3)
    log(acc_id, f"🔬 DUMP | код: {code} | xsrf_age: {cache_age}с | до_post: {t_xsrf_ready}с | xsrf: {xsrf[:10]}...")

    try:
        # ── POST activate ────────────────────────────────────
        r = session.post(
            ACTIVATE_URL,
            json={"action": "activate", "code": code},
            headers=headers,
            timeout=(TIMEOUT_CONNECT, TIMEOUT_READ),
        )
        elapsed      = round(time.time() - t0, 3)
        post_elapsed = round(time.time() - t_before_post, 3)
        body_raw     = r.content[:300].decode("utf-8", errors="replace")
        body_short   = body_raw

        # Декодируем unicode escape для читаемости
        import json as _json
        try:
            body_json = _json.loads(body_raw)
            body_msg  = body_json.get("message", body_raw)
        except Exception:
            body_msg = body_raw

        log(acc_id, f"📤 POST → {r.status_code} | post: {post_elapsed}с | total: {elapsed}с")
        log(acc_id, f"📥 ОТВЕТ: {body_msg[:150]}")

        # Полный дамп запроса и ответа
        req_headers = dict(r.request.headers)
        resp_headers = dict(r.headers)
        cookies_sent = {c.name: c.value[:20]+"..." for c in session.cookies}
        log(acc_id, f"🔬 REQ URL: {r.request.url}")
        log(acc_id, f"🔬 REQ BODY: {r.request.body[:200] if r.request.body else 'пусто'}")
        log(acc_id, f"🔬 REQ HEADERS: {_json.dumps({k: v[:30] for k,v in req_headers.items()}, ensure_ascii=False)}")
        log(acc_id, f"🔬 REQ COOKIES: {_json.dumps(cookies_sent, ensure_ascii=False)}")
        log(acc_id, f"🔬 RESP HEADERS: {_json.dumps({k: v[:50] for k,v in resp_headers.items()}, ensure_ascii=False)}")
        log(acc_id, f"🔬 RESP FULL: {body_raw[:500]}")

        # ── 419: XSRF истёк — один повтор ───────────────────
        if r.status_code == 419:
            log(acc_id, "🔁 419 XSRF — обновляю и повторяю...")
            xsrf = _fetch_fresh_tokens(session, acc_id)
            if not xsrf:
                return {"success": False, "message": "419 + нет XSRF",
                        "status_code": 419, "elapsed": round(time.time()-t0, 3), "dump_records": []}
            headers["X-XSRF-TOKEN"] = xsrf
            t_retry = time.time()
            r = session.post(
                ACTIVATE_URL,
                json={"action": "activate", "code": code},
                headers=headers,
                timeout=(TIMEOUT_CONNECT, TIMEOUT_READ),
            )
            elapsed      = round(time.time() - t0, 3)
            retry_elapsed = round(time.time() - t_retry, 3)
            body_short   = r.content[:200].decode("utf-8", errors="replace")
            log(acc_id, f"📤 POST retry → {r.status_code} | {retry_elapsed}с (total {elapsed}с) | {body_short}")

        resp_text = r.content.decode("utf-8", errors="replace").lower()

        # ── Классификация ответа ─────────────────────────────
        SUCCESS_KW    = ["успешно", "активирован", "получили", "зачислен", "добавлен", "success"]
        LOGIC_FAIL_KW = ["не найден", "not found", "invalid", "недоступен",
                         "already", "used", "активирован ранее", "уже использован",
                         "истёк", "expired"]
        TECH_FAIL_KW  = ["попробуйте позже", "too many", "rate", "временно"]

        has_logic_fail = any(w in resp_text for w in LOGIC_FAIL_KW)
        has_tech_fail  = any(w in resp_text for w in TECH_FAIL_KW)

        if r.status_code == 200 and not has_logic_fail and not has_tech_fail:
            success = True
        elif r.status_code == 400:
            return {"success": False, "message": f"400: {body_short[:80]}",
                    "status_code": 400, "elapsed": elapsed, "dump_records": _dump(code, r)}
        elif r.status_code == 404 or has_logic_fail:
            return {"success": False, "message": f"not_found: {body_short[:80]}",
                    "status_code": r.status_code or 404, "elapsed": elapsed, "dump_records": _dump(code, r)}
        elif has_tech_fail:
            log(acc_id, f"⚠️ Rate-limit: {body_short[:80]}")
            return {"success": False, "message": f"rate_limit: {body_short[:80]}",
                    "status_code": 429, "elapsed": elapsed, "dump_records": _dump(code, r)}
        else:
            success = False

        return {
            "success":      success,
            "message":      body_short[:200],
            "status_code":  r.status_code,
            "elapsed":      elapsed,
            "dump_records": _dump(code, r),
        }

    except requests.Timeout:
        elapsed = round(time.time() - t0, 3)
        log(acc_id, f"⏱ HTTP Timeout {elapsed}с (connect={TIMEOUT_CONNECT}с, read={TIMEOUT_READ}с)")
        return {"success": False, "message": "Timeout", "status_code": 0,
                "elapsed": elapsed, "dump_records": []}
    except Exception as e:
        elapsed = round(time.time() - t0, 3)
        log(acc_id, f"❌ HTTP exception: {str(e)[:100]} ({elapsed}с)")
        return {"success": False, "message": str(e)[:100], "status_code": 0,
                "elapsed": elapsed, "dump_records": []}


def _dump(code: str, r) -> list:
    """Формирует dump_records для одного activate запроса."""
    try:    body = r.json()
    except: body = r.text
    return [{
        "url":         ACTIVATE_URL,
        "method":      "POST",
        "req_body":    {"action": "activate", "code": code},
        "resp_status": r.status_code,
        "resp_body":   body,
    }]
