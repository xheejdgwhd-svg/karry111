import socket, time, threading

TOKEN_SENDER   = "drh2hxksssf44lc7ao45p4q23n9my3"
TOKEN_LISTENER = "zydld1etsdu73a5ajaxkgsz0sjw2jc"
CHANNEL = "#kenkashi20"

ENDPOINTS = [
    ("irc.chat.twitch.tv", 6667),
    ("irc.chat.twitch.tv", 6697),
    ("irc.chat.twitch.tv", 443),
    ("irc2.chat.twitch.tv", 6667),
    ("irc3.chat.twitch.tv", 6667),
]

def test_endpoint(host, port):
    result = []
    
    def listener():
        try:
            s = socket.socket()
            s.settimeout(10)
            s.connect((host, port))
            s.send(("PASS oauth:" + TOKEN_LISTENER + "\r\n").encode())
            s.send(b"NICK prodeagle228\r\n")
            s.send(("JOIN " + CHANNEL + "\r\n").encode())
            time.sleep(2)
            buf = ""
            while True:
                data = s.recv(4096).decode("utf-8", errors="ignore")
                buf += data
                if "LATENCY_TEST_789" in buf:
                    result.append(time.time())
                    break
        except Exception as e:
            result.append(None)

    try:
        s = socket.socket()
        s.settimeout(10)
        s.connect((host, port))
        s.send(("PASS oauth:" + TOKEN_SENDER + "\r\n").encode())
        s.send(b"NICK kenkashi20\r\n")
        s.send(("JOIN " + CHANNEL + "\r\n").encode())
        time.sleep(2)
    except Exception as e:
        print(f"{host}:{port} — недоступен ({e})")
        return

    t = threading.Thread(target=listener)
    t.start()
    time.sleep(1)
    t_send = time.time()
    s.send(("PRIVMSG " + CHANNEL + " :LATENCY_TEST_789\r\n").encode())
    t.join(timeout=12)
    
    if result and result[0]:
        print(f"{host}:{port} — {round((result[0] - t_send)*1000, 1)}мс")
    else:
        print(f"{host}:{port} — Timeout")

for host, port in ENDPOINTS:
    test_endpoint(host, port)
    time.sleep(2)
