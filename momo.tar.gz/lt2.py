import socket, time, threading

TOKEN_SENDER   = "drh2hxksssf44lc7ao45p4q23n9my3"
TOKEN_LISTENER = "zydld1etsdu73a5ajaxkgsz0sjw2jc"
CHANNEL = "#kenkashi20"
result = []

def listener():
    s = socket.socket()
    s.settimeout(15)
    s.connect(("irc.chat.twitch.tv", 6667))
    s.send(("PASS oauth:" + TOKEN_LISTENER + "\r\n").encode())
    s.send(b"NICK prodeagle228\r\n")
    s.send(("JOIN " + CHANNEL + "\r\n").encode())
    time.sleep(2)
    buf = ""
    while True:
        try:
            data = s.recv(4096).decode("utf-8", errors="ignore")
            buf += data
            if "LATENCY_TEST_456" in buf:
                result.append(time.time())
                break
        except:
            break

def sender():
    s = socket.socket()
    s.settimeout(10)
    s.connect(("irc.chat.twitch.tv", 6667))
    s.send(("PASS oauth:" + TOKEN_SENDER + "\r\n").encode())
    s.send(b"NICK kenkashi20\r\n")
    s.send(("JOIN " + CHANNEL + "\r\n").encode())
    time.sleep(2)
    return s

s = sender()
t = threading.Thread(target=listener)
t.start()
time.sleep(1)
t_send = time.time()
s.send(("PRIVMSG " + CHANNEL + " :LATENCY_TEST_456\r\n").encode())
t.join(timeout=15)
if result:
    print("IRC latency: " + str(round((result[0] - t_send)*1000, 1)) + "мс")
else:
    print("Timeout")
