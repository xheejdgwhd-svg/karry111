python3 - << 'EOF'
import socket, time

sock = socket.socket()
sock.settimeout(10)
sock.connect(("irc.chat.twitch.tv", 6667))
sock.send(b"PASS oauth:7bbc72enwjm32clmc0pbukemwbifor\r\n")
sock.send(b"NICK kenkashi20\r\n")
sock.send(b"JOIN #kenkashi20\r\n")

time.sleep(2)
buf = ""
# Читаем пока не подключились
while "End of /NAMES" not in buf:
    buf += sock.recv(4096).decode("utf-8", errors="ignore")

t_send = time.time()
sock.send(b"PRIVMSG #henesseyyt :LATENCY_TEST_123\r\n")

buf = ""
while True:
    data = sock.recv(4096).decode("utf-8", errors="ignore")
    buf += data
    if "LATENCY_TEST_123" in buf:
        t_recv = time.time()
        print(f"IRC round-trip: {round((t_recv - t_send)*1000, 1)}мс")
        break
EOF
