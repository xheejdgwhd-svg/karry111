import websocket, time, threading

TOKEN_SENDER   = "drh2hxksssf44lc7ao45p4q23n9my3"
TOKEN_LISTENER = "zydld1etsdu73a5ajaxkgsz0sjw2jc"
CHANNEL = "#kenkashi20"

result = []

def listener():
    ws = websocket.WebSocket()
    ws.connect("wss://irc-ws.chat.twitch.tv:443")
    ws.send("PASS oauth:" + TOKEN_LISTENER)
    ws.send("NICK prodeagle228")
    ws.send("JOIN " + CHANNEL)
    time.sleep(2)
    while True:
        try:
            data = ws.recv()
            if "LATENCY_TEST_WSS" in data:
                result.append(time.time())
                break
        except:
            break

ws = websocket.WebSocket()
ws.connect("wss://irc-ws.chat.twitch.tv:443")
ws.send("PASS oauth:" + TOKEN_SENDER)
ws.send("NICK kenkashi20")
ws.send("JOIN " + CHANNEL)
time.sleep(2)

t = threading.Thread(target=listener)
t.start()
time.sleep(1)

t_send = time.time()
ws.send("PRIVMSG " + CHANNEL + " :LATENCY_TEST_WSS")
t.join(timeout=15)

if result:
    print("WSS latency: " + str(round((result[0] - t_send)*1000, 1)) + "мс")
else:
    print("Timeout")
