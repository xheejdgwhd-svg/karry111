#!/usr/bin/env python3

import os
import sys
import subprocess


WORKER_SECRET = "secret123"
IP_FILE = "/home/ubuntu/bot/ip_vm.txt"
WORKER_FILE = "/home/ubuntu/bot/worker.py"

NO_PORT_ACCOUNTS = {1, 3, 5, 7, 9}


def main():
    if len(sys.argv) < 2 or len(sys.argv) > 3:
        print("Использование:")
        print("  python3 splitter_command.py -6 -8080")
        print("  python3 splitter_command.py -3")
        sys.exit(1)

    try:
        acc_id = int(sys.argv[1].lstrip("-"))
    except ValueError:
        print("Ошибка: ID аккаунта должен быть числом.")
        sys.exit(1)

    port = None

    if len(sys.argv) == 3:
        try:
            port = int(sys.argv[2].lstrip("-"))
        except ValueError:
            print("Ошибка: порт должен быть числом.")
            sys.exit(1)

    with open(IP_FILE, "r") as f:
        ip = f.read().strip()

    if not ip:
        print("Ошибка: ip_vm.txt пустой.")
        sys.exit(1)

    env = os.environ.copy()

    env["ACC_ID"] = str(acc_id)
    env["WORKER_SECRET"] = WORKER_SECRET
    env["MAIN_URL"] = f"http://{ip}:8090"

    if acc_id in NO_PORT_ACCOUNTS:
        print(f"Запускаю Акк {acc_id} без WORKER_PORT")
    else:
        if port is None:
            print(f"Ошибка: для Акк {acc_id} нужно указать порт.")
            print(f"Пример: python3 splitter_command.py -{acc_id} -8081")
            sys.exit(1)

        env["WORKER_PORT"] = str(port)
        print(f"Запускаю Акк {acc_id} на порту {port}")

    subprocess.run(
        ["python3", "-u", WORKER_FILE],
        env=env,
        cwd="/home/ubuntu/bot"
    )


if __name__ == "__main__":
    main()
