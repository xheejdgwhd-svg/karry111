
import socket, time, threading

TOKEN_SENDER   = "drh2hxksssf44lc7ao45p4q23n9my3"
TOKEN_LISTENER = "zydld1etsdu73a5ajaxkgsz0sjw2jc"
CHANNEL = "#kenkashi20"
result = []

def listener():
    s = socket.socket()
    s.settimeout(15)
    s.connect(("irc.chat.twitch.tv", 6667))
    s.send(f"PASS oauth:{TOKEN_LISTENER}
".encode())
    s.send(b"NICK prodeagle228
")
    s.send(f"JOIN {CHANNEL}
".encode())
    time.sleep(2)
    buf = ""
    while True:
        try:
            data = s.recv(4096).decode("utf-8", errors="ignore")
            buf += data
            if "LATENCY_TEST_456" in buf:
                result.append(time.time())
                break
        except: break

def sender():
    s = socket.socket()
    s.settimeout(10)
    s.connect(("irc.chat.twitch.tv", 6667))
    s.send(f"PASS oauth:{TOKEN_SENDER}
".encode())
    s.send(b"NICK kenkashi20
")
    s.send(f"JOIN {CHANNEL}
".encode())
    time.sleep(2)
    return s

s = sender()
t = threading.Thread(target=listener)
t.start()
time.sleep(1)
t_send = time.time()
s.send(f"PRIVMSG {CHANNEL} :LATENCY_TEST_456
".encode())
t.join(timeout=15)
if result:
    print(f"IRC latency: {round((result[0] - t_send)*1000, 1)}мс")
else:
    print("Timeout")
